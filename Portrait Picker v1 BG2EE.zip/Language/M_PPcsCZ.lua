PPStrings = {
	PP_CHAR_MALE = "Muž",  -- 'Male'
	PP_CHAR_FEMALE = "Žena", -- 'Female'
	PP_SORTAZ = "od A do Z", -- 'A to Z'
	PP_SORTZA = "od Z do A", -- 'Z to A'
	PP_SORTDC = "Od Základních po Vlastní", -- 'Default to Custom'
	PP_SORTCD = "Od Vlastních po Základní", -- 'Custom to Default'
	PP_TOTAL = "Celkové množství Portrétů", -- 'TOTAL PORTRAITS'
	PP_DEFAULT = "Základní: ", -- 'Default: '
	PP_CUSTOM = "Vlastní: ", -- 'Custom: '
	PP_SORT = "Seřadit: ", -- 'Sort: '
	PP_SORT_LABEL = "Seřadit", -- 'SORT'
	PP_FILENAME = "Název souboru: " -- 'Filename'
}
