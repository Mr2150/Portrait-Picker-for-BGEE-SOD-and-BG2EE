
PPStrings = {
	PP_CHAR_MALE = "Homem",  -- 'Male'
	PP_CHAR_FEMALE = "Mulher", -- 'Female'
	PP_SORTAZ = "A a Z", -- 'A to Z'
	PP_SORTZA = "Z a A", -- 'Z to A'
	PP_SORTDC = "Padrão depois Personalizado", -- 'Default to Custom'
	PP_SORTCD = "Personalizado depois Padrão", -- 'Custom to Default'
	PP_TOTAL = "TOTAL DE RETRATOS", -- 'TOTAL PORTRAITS'
	PP_DEFAULT = "Padrão: ", -- 'Default: '
	PP_CUSTOM = "Personalizado: ", -- 'Custom: '
	PP_SORT = "Classificar: ", -- 'Sort: '
	PP_SORT_LABEL = "CLASSIFICAR", -- 'SORT'
	PP_FILENAME = "Nome do Arquivo: " -- 'Filename: '
}
