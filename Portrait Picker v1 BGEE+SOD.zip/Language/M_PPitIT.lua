
PPStrings = {
	PP_CHAR_MALE = "Maschile",  -- 'Male'
	PP_CHAR_FEMALE = "Femminile", -- 'Female'
	PP_SORTAZ = "Dalla A alla Z", -- 'A to Z'
	PP_SORTZA = "Dalla Z alla A", -- 'Z to A'
	PP_SORTDC = "Predefiniti poi Personalizzati", -- 'Default to Custom'
	PP_SORTCD = "Personalizzati poi Predefiniti", -- 'Custom to Default'
	PP_TOTAL = "TOTALE RITRATTI", -- 'TOTAL PORTRAITS'
	PP_DEFAULT = "Predefiniti: ", -- 'Default: '
	PP_CUSTOM = "Personalizzati: ", -- 'Custom: '
	PP_SORT = "Ordina: ", -- 'Sort: '
	PP_SORT_LABEL = "ORDINA", -- 'SORT'
	PP_FILENAME = "Nome File: " -- 'Filename'
}
