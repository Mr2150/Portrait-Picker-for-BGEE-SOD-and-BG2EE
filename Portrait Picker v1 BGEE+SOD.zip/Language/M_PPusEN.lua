
PPStrings = {
	PP_CHAR_MALE = "Male",  -- 'Male'
	PP_CHAR_FEMALE = "Female", -- 'Female'
	PP_SORTAZ = "A to Z", -- 'A to Z'
	PP_SORTZA = "Z to A", -- 'Z to A'
	PP_SORTDC = "Default to Custom", -- 'Default to Custom'
	PP_SORTCD = "Custom to Default", -- 'Custom to Default'
	PP_TOTAL = "TOTAL PORTRAITS", -- 'TOTAL PORTRAITS'
	PP_DEFAULT = "Default: ", -- 'Default: '
	PP_CUSTOM = "Custom: ", -- 'Custom: '
	PP_SORT = "Sort: ", -- 'Sort: '
	PP_SORT_LABEL = "SORT", -- 'SORT'
	PP_FILENAME = "Filename: " -- 'Filename'
}
