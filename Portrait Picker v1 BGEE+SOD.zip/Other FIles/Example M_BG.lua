BGImages = {
{"Samurai","F","port 01"},
{"Cleric","M","port 02"},
{"Elf Warrior","F","port 03"},
{"Happy Fighter","M","port 04"},
{"Cool Archer","D","port 05"},
{"Happy Cleric","F","port 06"},
{"Angry Fighter","M","port 07"},
{"Young Mage","D","port 08"},
{"Older Mage","F","port 09"},
{"Angry Fighter","M","port 10"},
{"Thief Cool Hair","F","port 11"},
{"Thief Mage Cool","D","port 12"},
{"Angry Mage","M","port 13"},
{"Ranger Cool","M","port 14"},
{"Happy","F","port 15"}
}